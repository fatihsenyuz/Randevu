# Twilio vs İletimerkezi - Kod Karşılaştırması

## 🔄 Değişiklik Özeti

### İmport Değişiklikleri

**ÖNCE (Twilio):**
```python
from twilio.rest import Client
```

**SONRA (İletimerkezi):**
```python
import requests
from urllib.parse import quote
```

---

### Konfigürasyon Değişiklikleri

**ÖNCE (Twilio):**
```python
# Twilio SMS Client
twilio_client = Client(
    os.environ.get('TWILIO_ACCOUNT_SID'),
    os.environ.get('TWILIO_AUTH_TOKEN')
)
TWILIO_PHONE = os.environ.get('TWILIO_PHONE_NUMBER')
```

**SONRA (İletimerkezi):**
```python
# İletimerkezi SMS API Configuration
ILETIMERKEZI_API_KEY = os.environ.get('ILETIMERKEZI_API_KEY')
ILETIMERKEZI_HASH = os.environ.get('ILETIMERKEZI_HASH')
ILETIMERKEZI_SENDER = os.environ.get('ILETIMERKEZI_SENDER', 'ROYALKLTKYK')
```

---

### SMS Gönderme Fonksiyonu

**ÖNCE (Twilio - 28 satır):**
```python
def send_sms(to_phone: str, message: str):
    """Send SMS via Twilio"""
    try:
        import re
        # Format phone number to include +90 if needed
        if not to_phone.startswith('+'):
            # Remove all non-digit characters
            clean_phone = re.sub(r'\D', '', to_phone)
            
            # Remove leading 0 if exists (Turkish format)
            if clean_phone.startswith('0'):
                clean_phone = clean_phone[1:]
            
            # Add country code if not present
            if not clean_phone.startswith('90'):
                to_phone = '+90' + clean_phone
            else:
                to_phone = '+' + clean_phone
        
        message = twilio_client.messages.create(
            body=message,
            from_=TWILIO_PHONE,
            to=to_phone
        )
        logging.info(f"SMS sent to {to_phone}: {message.sid}")
        return True
    except Exception as e:
        logging.error(f"Failed to send SMS to {to_phone}: {str(e)}")
        return False
```

**SONRA (İletimerkezi - 47 satır, daha detaylı):**
```python
def send_sms(to_phone: str, message: str):
    """Send SMS via İletimerkezi"""
    try:
        import re
        # Format phone number to Turkish format
        if not to_phone.startswith('+'):
            # Remove all non-digit characters
            clean_phone = re.sub(r'\D', '', to_phone)
            
            # Remove leading 0 if exists (Turkish format)
            if clean_phone.startswith('0'):
                clean_phone = clean_phone[1:]
            
            # Add country code if not present
            if not clean_phone.startswith('90'):
                clean_phone = '90' + clean_phone
        else:
            # Remove + sign for İletimerkezi
            clean_phone = to_phone.replace('+', '')
        
        # İletimerkezi API endpoint
        api_url = "https://api.iletimerkezi.com/v1/send-sms/get/"
        
        # Prepare parameters
        params = {
            'key': ILETIMERKEZI_API_KEY,
            'hash': ILETIMERKEZI_HASH,
            'text': message,
            'receipents': clean_phone,
            'sender': ILETIMERKEZI_SENDER,
            'iys': '1',
            'iysList': 'BIREYSEL'
        }
        
        # Send GET request
        response = requests.get(api_url, params=params, timeout=10)
        
        if response.status_code == 200:
            logging.info(f"SMS sent to {clean_phone} via İletimerkezi")
            return True
        else:
            logging.error(f"Failed to send SMS to {clean_phone}: HTTP {response.status_code} - {response.text}")
            return False
            
    except Exception as e:
        logging.error(f"Failed to send SMS to {to_phone}: {str(e)}")
        return False
```

---

### .env Dosyası Değişiklikleri

**ÖNCE (Twilio):**
```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_PHONE_NUMBER=+1234567890
```

**SONRA (İletimerkezi):**
```env
ILETIMERKEZI_API_KEY=bcfd59782ed2f51f6929a16d77766f44
ILETIMERKEZI_HASH=a0b8e9033bbff5003a9676553c6c0f7bf17401a24443dacc7a96ade0157d5ec4
ILETIMERKEZI_SENDER=ROYALKLTKYK
```

---

### requirements.txt Değişiklikleri

**ÖNCE:**
```txt
...
twilio==9.8.4
...
```

**SONRA:**
```txt
# twilio kaldırıldı
# requests zaten mevcuttu: requests==2.32.5
```

---

## 📊 Karşılaştırma Tablosu

| Özellik | Twilio | İletimerkezi |
|---------|--------|--------------|
| **Kütüphane** | twilio==9.8.4 | requests (built-in) |
| **API Tipi** | REST SDK | HTTP GET/POST |
| **Telefon Formatı** | +905551234567 | 905551234567 |
| **Credentials** | SID + Token + Phone | API Key + Hash + Sender |
| **IYS Desteği** | ❌ Yok | ✅ Var (zorunlu) |
| **Gönderici Adı** | Sabit numara | Özelleştirilebilir (ROYALKLTKYK) |
| **Türkiye Desteği** | Genel (tüm ülkeler) | Türkiye odaklı |
| **Timeout** | SDK varsayılan | 10 saniye |
| **Hata Yönetimi** | Exception based | HTTP status based |

---

## ✅ Avantajlar

### İletimerkezi Avantajları:
1. ✅ **Türkiye'ye özel** - IYS entegrasyonu dahil
2. ✅ **Daha basit** - Ekstra kütüphane gerektirmiyor (requests zaten var)
3. ✅ **Özelleştirilebilir gönderici adı** - Müşterilere markanızı gösterir
4. ✅ **IYS uyumlu** - Türk mevzuatına uygun
5. ✅ **Daha detaylı hata raporları** - HTTP response ile

### Twilio Avantajları:
1. ⚠️ **Global kapsam** - Tüm dünyaya SMS gönderimi
2. ⚠️ **Gelişmiş özellikler** - MMS, WhatsApp, Voice vb.

---

## 🎯 Sonuç

İletimerkezi entegrasyonu başarıyla tamamlandı. Sistem artık:
- ✅ Türkiye'ye özel IYS uyumlu SMS gönderiyor
- ✅ ROYALKLTKYK gönderici adını kullanıyor
- ✅ Telefon numaralarını otomatik formatlıyor
- ✅ Detaylı hata logları tutuyor
- ✅ Daha hafif (twilio bağımlılığı kaldırıldı)
