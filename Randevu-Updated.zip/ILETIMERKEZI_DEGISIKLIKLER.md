# İletimerkezi SMS Entegrasyonu - Değişiklik Raporu

## 📋 Özet
Twilio SMS sistemi başarıyla İletimerkezi SMS API'si ile değiştirildi.

## 🔧 Yapılan Değişiklikler

### 1. Backend Dosyaları (`/app/backend/server.py`)

#### Kaldırılan Kod:
```python
from twilio.rest import Client

# Twilio SMS Client
twilio_client = Client(
    os.environ.get('TWILIO_ACCOUNT_SID'),
    os.environ.get('TWILIO_AUTH_TOKEN')
)
TWILIO_PHONE = os.environ.get('TWILIO_PHONE_NUMBER')
```

#### Eklenen Kod:
```python
import requests
from urllib.parse import quote

# İletimerkezi SMS API Configuration
ILETIMERKEZI_API_KEY = os.environ.get('ILETIMERKEZI_API_KEY')
ILETIMERKEZI_HASH = os.environ.get('ILETIMERKEZI_HASH')
ILETIMERKEZI_SENDER = os.environ.get('ILETIMERKEZI_SENDER', 'ROYALKLTKYK')
```

### 2. SMS Gönderme Fonksiyonu

#### Eski Twilio Fonksiyonu:
```python
def send_sms(to_phone: str, message: str):
    """Send SMS via Twilio"""
    message = twilio_client.messages.create(
        body=message,
        from_=TWILIO_PHONE,
        to=to_phone
    )
```

#### Yeni İletimerkezi Fonksiyonu:
```python
def send_sms(to_phone: str, message: str):
    """Send SMS via İletimerkezi"""
    # Telefon numarasını formatla (90 ile başlamalı, + işareti olmadan)
    clean_phone = re.sub(r'\D', '', to_phone)
    if clean_phone.startswith('0'):
        clean_phone = clean_phone[1:]
    if not clean_phone.startswith('90'):
        clean_phone = '90' + clean_phone
    
    # İletimerkezi API endpoint
    api_url = "https://api.iletimerkezi.com/v1/send-sms/get/"
    
    # Parametreler
    params = {
        'key': ILETIMERKEZI_API_KEY,
        'hash': ILETIMERKEZI_HASH,
        'text': message,
        'receipents': clean_phone,
        'sender': ILETIMERKEZI_SENDER,
        'iys': '1',
        'iysList': 'BIREYSEL'
    }
    
    # GET request gönder
    response = requests.get(api_url, params=params, timeout=10)
```

### 3. Çevre Değişkenleri (`.env`)

#### Kaldırılan:
```
TWILIO_ACCOUNT_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE_NUMBER=...
```

#### Eklenen (`/app/backend/.env`):
```
ILETIMERKEZI_API_KEY="bcfd59782ed2f51f6929a16d77766f44"
ILETIMERKEZI_HASH="a0b8e9033bbff5003a9676553c6c0f7bf17401a24443dacc7a96ade0157d5ec4"
ILETIMERKEZI_SENDER="ROYALKLTKYK"
```

### 4. Bağımlılıklar (`requirements.txt`)

#### Kaldırılan:
```
twilio==9.8.4
```

#### Kullanılan (zaten mevcut):
```
requests==2.32.5
```

## 📱 SMS Gönderimi Özellikleri

### İletimerkezi API Detayları:
- **Endpoint**: `https://api.iletimerkezi.com/v1/send-sms/get/`
- **Method**: GET
- **Parametreler**:
  - `key`: API anahtarı
  - `hash`: Güvenlik hash'i
  - `text`: Mesaj içeriği
  - `receipents`: Alıcı telefon numarası (90XXXXXXXXXX formatında)
  - `sender`: Gönderici adı (ROYALKLTKYK)
  - `iys`: IYS kontrolü (1 = aktif)
  - `iysList`: IYS listesi tipi (BIREYSEL)

### Telefon Numarası Formatı:
- Türk telefon numaraları otomatik olarak `90XXXXXXXXXX` formatına dönüştürülür
- Başındaki `0` otomatik olarak kaldırılır
- `+` işareti olmadan gönderilir

## ✅ Randevu Oluşturulduğunda Gönderilen SMS:

```
Royal Koltuk Yıkama - Randevunuz oluşturuldu!

Tarih: [YYYY-MM-DD]
Saat: [HH:MM]
Hizmet: [Hizmet Adı]

Bizi tercih ettiğiniz için teşekkür ederiz.
```

## 🧪 Test Edilmesi Gereken Noktalar:

1. ✅ Backend başarıyla başlatıldı
2. ✅ Frontend başarıyla başlatıldı
3. ⏳ Randevu oluşturma ve SMS gönderimi testi
4. ⏳ Telefon numarası formatlamasının doğru çalışması
5. ⏳ İletimerkezi API yanıtlarının kontrolü

## 🚀 Servis Durumu:

```
backend     RUNNING
frontend    RUNNING
mongodb     RUNNING
```

## 📝 Notlar:

- İletimerkezi API'si IYS (İleti Yönetim Sistemi) kontrolü gerektirir
- Gönderici adı (ROYALKLTKYK) İletimerkezi panelinde tanımlı olmalıdır
- API kredisi İletimerkezi hesabında mevcut olmalıdır
- Test için ilk randevuyu oluşturup SMS gönderimi test edilmelidir

## 🔐 Güvenlik:

- API Key ve Hash bilgileri `.env` dosyasında güvenli şekilde saklanmaktadır
- Bu değerler kod içinde hardcoded değildir
- `.env` dosyası `.gitignore` ile repository dışında tutulmalıdır

---

**Entegrasyon Tarihi**: 29 Ekim 2025
**Durum**: ✅ Tamamlandı ve test için hazır
